'''
Department of Computer Science, University of Bristol
COMS30030: Image Processing and Computer Vision

3-D from Stereo: Coursework Part 2
3-D simulator

Yuhang Ming yuhang.ming@bristol.ac.uk
Andrew Calway andrew@cs.bris.ac.uk
'''

import cv2
import open3d as o3d
import matplotlib.pyplot as plt
import numpy as np
import math
import random
import argparse


'''
Interaction menu:
P  : Take a screen capture.
D  : Take a depth capture.

Official doc on visualisation interactions:
http://www.open3d.org/docs/latest/tutorial/Basic/visualization.html
'''

# 用于将3D点转换到不同坐标系下。
def transform_points(points, H):
    '''
    transform list of 3-D points using 4x4 coordinate transformation matrix H
    converts points to homogeneous coordinates prior to matrix multiplication

    input:
      points: Nx3 matrix with each row being a 3-D point
      H: 4x4 transformation matrix

    return:
      new_points: Nx3 matrix with each row being a 3-D point
    '''
    # compute pt_w = H * pt_c
    n,m = points.shape
    if m == 4:
        new_points = points
    else:
        new_points = np.concatenate([points, np.ones((n,1))], axis=1)
    new_points = H.dot(new_points.transpose())
    new_points = new_points / new_points[3,:]
    new_points = new_points[:3,:].transpose()
    return new_points

# 这个函数是确保生成的球体不会重叠
def check_dup_locations(y, z, loc_list):
    for (loc_y, loc_z) in loc_list:
        if loc_y == y and loc_z == z:
            return True


# print("here", flush=True)
if __name__ == '__main__':

    #使用argparse库从命令行接收参数，如球体数量、球体半径和间隔的最小/最大值。
    ####################################
    ### Take command line arguments ####
    ####################################

    parser = argparse.ArgumentParser()
    parser.add_argument('--num', dest='num', type=int, default=6,
                        help='number of spheres')
    # 最小和最大球体半径,他后面创建的时候min和max都除以10了
    parser.add_argument('--sph_rad_min', dest='sph_rad_min', type=int, default=10,
                        help='min sphere  radius x10')
    parser.add_argument('--sph_rad_max', dest='sph_rad_max', type=int, default=16,
                        help='max sphere  radius x10')
    # 最小和最大球体间隔
    # parser.add_argument('--sph_sep_min', dest='sph_sep_min', type=int, default=4,
    #                    help='min sphere  separation')
    parser.add_argument('--sph_sep_min', dest='sph_sep_min', type=int, default=6,
                       help='min sphere  separation')
    parser.add_argument('--sph_sep_max', dest='sph_sep_max', type=int, default=7,
                       help='max sphere  separation')
    parser.add_argument('--display_centre', dest='bCentre', action='store_true',
                        help='open up another visualiser to visualise centres')
    parser.add_argument('--coords', dest='bCoords', action='store_true')

    args = parser.parse_args()

    if args.num<=0:
        print('invalidnumber of spheres')
        exit()

    if args.sph_rad_min>=args.sph_rad_max or args.sph_rad_min<=0:
        print('invalid max and min sphere radii')
        exit()

    if args.sph_sep_min>=args.sph_sep_max or args.sph_sep_min<=0:
        print('invalid max and min sphere separation')
        exit()

    ####################################
    #### Setup objects in the scene ####
    ####################################
    # 创建平面和球体，并随机分配球体的位置和大小。

    # create plane to hold all spheres
    h, w = 24, 12
    # place the support plane on the x-z plane
    box_mesh=o3d.geometry.TriangleMesh.create_box(width=h,height=0.05,depth=w)
    box_H=np.array(
                 [[1, 0, 0, -h/2],
                  [0, 1, 0, -0.05],
                  [0, 0, 1, -w/2],
                  [0, 0, 0, 1]]
                )
    box_rgb = [0.7, 0.7, 0.7]
    name_list = ['plane']
    mesh_list, H_list, RGB_list = [box_mesh], [box_H], [box_rgb]

    # create spheres
    prev_loc = []
    GT_cents, GT_rads = [], []
    for i in range(args.num):
        # add sphere name
        name_list.append(f'sphere_{i}')

        # create sphere with random radius
        size = random.randrange(args.sph_rad_min, args.sph_rad_max, 2)/10
        sph_mesh=o3d.geometry.TriangleMesh.create_sphere(radius=size)
        mesh_list.append(sph_mesh)
        RGB_list.append([0., 0.5, 0.5])

        # create random sphere location
        step = random.randrange(args.sph_sep_min,args.sph_sep_max,1)
        x = random.randrange(-h/2+2, h/2-2, step)
        z = random.randrange(-w/2+2, w/2-2, step)
        while check_dup_locations(x, z, prev_loc):
            x = random.randrange(-h/2+2, h/2-2, step)
            z = random.randrange(-w/2+2, w/2-2, step)
        prev_loc.append((x, z))

        GT_cents.append(np.array([x, size, z, 1.]))
        GT_rads.append(size)
        sph_H = np.array(
                    [[1, 0, 0, x],
                     [0, 1, 0, size],
                     [0, 0, 1, z],
                     [0, 0, 0, 1]]
                )
        H_list.append(sph_H)

    # arrange plane and sphere in the space
    obj_meshes = []
    for (mesh, H, rgb) in zip(mesh_list, H_list, RGB_list):
        # apply location
        mesh.vertices = o3d.utility.Vector3dVector(
            transform_points(np.asarray(mesh.vertices), H)
        )
        # paint meshes in uniform colours here
        mesh.paint_uniform_color(rgb)
        mesh.compute_vertex_normals()
        obj_meshes.append(mesh)

    # add optional coordinate system
    if args.bCoords:
        coord_frame = o3d.geometry.TriangleMesh.create_coordinate_frame(size=1., origin=[0, 0, 0])
        obj_meshes = obj_meshes+[coord_frame]
        RGB_list.append([1., 1., 1.])
        name_list.append('coords')


    ###################################
    #### Setup camera orientations ####
    ###################################
    #相机设置: 设置两个虚拟相机的位置和方向。
    # set camera pose (world to camera)
    # # camera init
    # # placed at the world origin, and looking at z-positive direction,
    # # x-positive to right, y-positive to down
    # H_init = np.eye(4)
    # print(H_init)

    # camera_0 (world to camera)
    #相机的方向是通过在预设角度周围添加随机偏差实现的。例如，random.uniform(-5, 5)会在指定的角度上加上一个-5到5度的随机偏差，使得每次相机的视角都略有不同。
    theta = np.pi * (45*5+random.uniform(-5, 5))/180.
    #这里很关键，这个就是相机的外部参数（包括相机的位置和方向）
    H0_wc = np.array(
                [[1,            0,              0,  0],
                [0, np.cos(theta), -np.sin(theta),  0],
                [0, np.sin(theta),  np.cos(theta), 20],
                [0, 0, 0, 1]]
            )

    # camera_1 (world to camera)
    theta = np.pi * (80+random.uniform(-10, 10))/180.
    H1_0 = np.array(
                [[np.cos(theta),  0, np.sin(theta), 0],
                 [0,              1, 0,             0],
                 [-np.sin(theta), 0, np.cos(theta), 0],
                 [0, 0, 0, 1]]
            )
    theta = np.pi * (45*5+random.uniform(-5, 5))/180.
    H1_1 = np.array(
                [[1, 0,            0,              0],
                [0, np.cos(theta), -np.sin(theta), -4],
                [0, np.sin(theta), np.cos(theta),  20],
                [0, 0, 0, 1]]
            )
    H1_wc = np.matmul(H1_1, H1_0)
    render_list = [(H0_wc, 'view0.png', 'depth0.png'),
                   (H1_wc, 'view1.png', 'depth1.png')]

#####################################################
    # NOTE: This section relates to rendering scenes in Open3D, details are not
    # critical to understanding the lab, but feel free to read Open3D docs
    # to understand how it works.

    # 这里是相机的内部参数，包括相机的焦距、像素中心等
    # set up camera intrinsic matrix needed for rendering in Open3D
    img_width=640
    img_height=480
    f=415 # focal length
    # image centre in pixel coordinates
    ox=img_width/2-0.5
    oy=img_height/2-0.5
    K = o3d.camera.PinholeCameraIntrinsic(img_width,img_height,f,f,ox,oy)

    # Rendering RGB-D frames given camera poses
    # create visualiser and get rendered views
    cam = o3d.camera.PinholeCameraParameters()
    cam.intrinsic = K
    vis = o3d.visualization.Visualizer()
    vis.create_window(width=img_width, height=img_height, left=0, top=0)
    for m in obj_meshes:
        vis.add_geometry(m)
    ctr = vis.get_view_control()
    for (H_wc, name, dname) in render_list:
        cam.extrinsic = H_wc
        ctr.convert_from_pinhole_camera_parameters(cam)
        vis.poll_events()
        vis.update_renderer()
        vis.capture_screen_image(name, True)
        vis.capture_depth_image(dname, True)
    vis.run()
    vis.destroy_window()
##################################################

    # load in the images for post processings
    img0 = cv2.imread('view0.png', -1)
    dep0 = cv2.imread('depth0.png', -1)
    img1 = cv2.imread('view1.png', -1)
    dep1 = cv2.imread('depth1.png', -1)

    # visualise sphere centres
    pcd_GTcents = o3d.geometry.PointCloud()
    pcd_GTcents.points = o3d.utility.Vector3dVector(np.array(GT_cents)[:, :3])
    pcd_GTcents.paint_uniform_color([1., 0., 0.])
    if args.bCentre:
        vis = o3d.visualization.Visualizer()
        vis.create_window(width=640, height=480, left=0, top=0)
        for m in [obj_meshes[0], pcd_GTcents]:
            vis.add_geometry(m)
        vis.run()
        vis.destroy_window()

    '''
    Task 3: Circle detection
    Hint: use cv2.HoughCircles() for circle detection.
    https://docs.opencv.org/4.x/dd/d1a/group__imgproc__feature.html#ga47849c3be0d0406ad3ca45db65a25d2d

    '''
    # 应用霍夫圆变换
    view0_gray = cv2.cvtColor(img0, cv2.COLOR_BGR2GRAY)
    view0_blur = cv2.GaussianBlur(view0_gray, (5, 5), cv2.BORDER_DEFAULT)

    view1_gray = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    view1_blur = cv2.GaussianBlur(view1_gray, (5, 5), cv2.BORDER_DEFAULT)

    #这个效果看起来很好，但是我偷偷改了前面随机的参数
    # circles0 = cv2.HoughCircles(view0_blur, cv2.HOUGH_GRADIENT, 1, view0_blur.shape[0] / 10, param1=115, param2=13,
    #                             minRadius=0, maxRadius=50)
    #
    # circles1 = cv2.HoughCircles(view1_blur, cv2.HOUGH_GRADIENT, 1, view1_blur.shape[0] / 10, param1=115, param2=13,
    #                             minRadius=0, maxRadius=50)
    circles0 = cv2.HoughCircles(view0_blur, cv2.HOUGH_GRADIENT, 1, view0_blur.shape[0] / 10, param1=115, param2=13,
                                 minRadius=0, maxRadius=50)

    circles1 = cv2.HoughCircles(view1_blur, cv2.HOUGH_GRADIENT, 1, view1_blur.shape[0] / 10, param1=115,param2=13,
                                minRadius=0, maxRadius=50)

    # 绘制检测到的圆
    if circles0 is not None:
        circles = np.uint16(np.around(circles0))
        for i in circles[0, :]:
            center = (i[0], i[1])  # 圆心坐标
            radius = i[2]  # 半径
            cv2.circle(img0, center, radius, (0, 0, 255), 2)

    if circles1 is not None:
        circles = np.uint16(np.around(circles1))
        for i in circles[0, :]:
            center = (i[0], i[1])
            radius = i[2]
            cv2.circle(img1, center, radius, (0, 0, 255), 2)
    # 保存图像
    cv2.imwrite('HoughImg/houghimg0.png', img0)
    cv2.imwrite('HoughImg/houghimg1.png', img1)

    ###################################
    # '''
    # Task 4: Epipolar line
    # Hint: Compute Essential & Fundamental Matrix
    #       Draw lines with cv2.line() function
    # https://docs.opencv.org/4.x/d6/d6e/group__imgproc__draw.html#ga7078a9fae8c7e7d13d24dac2520ae4a2
    # '''

    # 提取相机0和相机1的相对旋转和平移
    R0, t0 = H0_wc[:3, :3], H0_wc[:3, 3]
    R1, t1 = H1_wc[:3, :3], H1_wc[:3, 3]
    R_rel = R1 @ np.linalg.inv(R0)
    t_rel = t1 - R_rel @ t0

    # 构建平移向量的反对称矩阵
    S = np.array([[0, -t_rel[2], t_rel[1]],
                    [t_rel[2], 0, -t_rel[0]],
                    [-t_rel[1], t_rel[0], 0]])

    # 计算本质矩阵
    E = S @ R_rel

    # 构建相机内参矩阵
    K_matrix = np.array([[f, 0, ox], [0, f, oy], [0, 0, 1]])

    # 计算基础矩阵
    F = np.linalg.inv(K_matrix).T @ E @ np.linalg.inv(K_matrix)

    # 绘制相机0中检测到的圆心在相机1图像上的极线
    if circles0 is not None:
        for i in circles0[0, :]:
            point = np.array([i[0], i[1], 1])  # 圆心的齐次坐标
            line = F @ point  # 计算对应的极线
            # 极线的两个端点
            pt1 = (0, int(-line[2] / line[1]))
            pt2 = (img_width, int(-(line[2] + line[0] * img_width) / line[1]))
            # 在相机1的图像上绘制极线
            cv2.line(img1, pt1, pt2, (0, 255, 0), 2)

    # 保存绘制了极线的图像
    cv2.imwrite('EpipolarLines/epipolar_img1.png', img1)

    # 接下来再反着画一遍极线！！！

    # 计算相机1到相机0的本质矩阵 E'
    R_rel_inv = np.linalg.inv(R_rel)
    t_rel_inv = -R_rel_inv @ t_rel
    S_inv = np.array([[0, -t_rel_inv[2], t_rel_inv[1]],
                      [t_rel_inv[2], 0, -t_rel_inv[0]],
                      [-t_rel_inv[1], t_rel_inv[0], 0]])
    E_inv = S_inv @ R_rel_inv

    # 计算相机1到相机0的基础矩阵 F'
    F_inv = np.linalg.inv(K_matrix).T @ E_inv @ np.linalg.inv(K_matrix)

    # 绘制相机1中检测到的圆心在相机0图像上的极线
    if circles1 is not None:
        for i in circles1[0, :]:
            point = np.array([i[0], i[1], 1])  # 圆心的齐次坐标
            line = F_inv @ point  # 计算对应的极线
            # 极线的两个端点
            pt1_inv = (0, int(-line[2] / line[1]))
            pt2_inv = (img_width, int(-(line[2] + line[0] * img_width) / line[1]))
            # 在相机0的图像上绘制极线
            cv2.line(img0, pt1_inv, pt2_inv, (0, 255, 0), 2)

    # 保存绘制了极线的图像
    cv2.imwrite('EpipolarLines/epipolar_img0.png', img0)

    ###################################
    '''
    Task 5: Find correspondences
    '''
    # 重新搞两张新图片
    img0new = cv2.imread('view0.png', -1)
    img1new = cv2.imread('view1.png', -1)

    # 我发现这个代码还是会出现误匹配的情况，我回头得再思考一下
    # circles0和circle1是霍夫变换检测到的圆心，这个里面还有半径！！！，F是基础矩阵
    def draw_circle_matches(img0new, img1new, circles0, circles1):
        img0_with_matches = img0new.copy()
        img1_with_matches = img1new.copy()
        matched_circles = []  # 新增：用于保存匹配的圆心对

        # 双向匹配
        for i0, (x0, y0, r0) in enumerate(circles0[0, :]):
            point0 = np.array([x0, y0, 1])  # 圆心0的齐次坐标
            line1 = F @ point0  # 圆心0在图像1上对应的极线

            # 在图像1中找到最接近极线的圆心
            closest_circle1 = None
            min_distance = float('inf')
            for i1, (x1, y1, r1) in enumerate(circles1[0, :]):
                point1 = np.array([x1, y1, 1])
                distance = abs(np.dot(line1, point1)) / np.linalg.norm(line1[:2])
                if distance < min_distance:
                    min_distance = distance
                    closest_circle1 = (i1, x1, y1,r1)

            if closest_circle1 is not None:
                _, closest_x1, closest_y1, closest_r1 = closest_circle1

                # 反向匹配：从图像1到图像0
                # 对于我们根据图像0找道德图像1中的极线的最好的圆心
                # 我们再用这个图像1中找到的最好的圆心，去找图像0中极线的最好的圆心
                # 比较这两个结果是否相同
                point1 = np.array([closest_x1, closest_y1, 1])
                line0 = F_inv @ point1
                min_distance_back = float('inf')
                back_match = None
                for x0_back, y0_back, _ in circles0[0, :]:
                    point0_back = np.array([x0_back, y0_back, 1])
                    distance_back = abs(np.dot(line0, point0_back)) / np.linalg.norm(line0[:2])
                    if distance_back < min_distance_back:
                        min_distance_back = distance_back
                        back_match = (x0_back, y0_back)

                # 如果反向匹配也指向原始圆心，则认为匹配有效
                if back_match and back_match[0] == x0 and back_match[1] == y0:
                    color = (np.random.randint(0, 255), np.random.randint(0, 255), np.random.randint(0, 255))
                    cv2.circle(img0_with_matches, (int(x0), int(y0)), 5, color, -1)
                    cv2.circle(img1_with_matches, (int(closest_x1), int(closest_y1)), 5, color, -1)
                    # 我真操了，这个地方要非常注意，这个顺序反了，直接后面就炸了！
                    matched_circles.append([[closest_x1, closest_y1, closest_r1],[x0, y0, r0]])

        return img0_with_matches, img1_with_matches, matched_circles

    matched_img0, matched_img1, matched_circles = draw_circle_matches(img0new, img1new, circles0, circles1)
    cv2.imwrite('correspondPoint/matched_circles_img0.png', matched_img0)
    cv2.imwrite('correspondPoint/matched_circles_img1.png', matched_img1)

    # 到这里matched_circles含有的是匹配的圆心对，然后接下来需要进行三维重建计算出圆心的三维坐标
    '''
    Task 6: 3-D locations of sphere centres

    Write your code here
    '''
    # Here is a simple implemention of the 3D reconstruction algorithm.
    # transform_points(center_coordinate.reshape(1,3),np.linalg.inv(H0_wc)) must be done to map the coordinate
    # back to world coordinate
    centers = []
    K_inverse = np.linalg.inv(K.intrinsic_matrix)
    H_10 = np.matmul(H0_wc, np.linalg.inv(H1_wc))
    rotation_matrix = H_10[:3, :3].T
    T = H_10[:3, 3]
    for correspondance in matched_circles:
        l = correspondance[1][:2]
        l.append(1)
        l = np.array(l)
        r = correspondance[0][:2]
        r.append(1)
        r = np.array(r)
        l = np.matmul(K_inverse, l)
        r = np.matmul(K_inverse, r)
        j = -np.matmul(rotation_matrix.T, r)
        k = -np.cross(l, np.matmul(rotation_matrix.T, r))
        H = np.concatenate((l.reshape(3, 1), j.reshape(3, 1), k.reshape(3, 1)), axis=1)
        reconstruct_array = np.matmul(np.linalg.inv(H), T)
        center_coordinate = (reconstruct_array[0] * l + reconstruct_array[1] * np.matmul(rotation_matrix.T, r) + T) / 2
        result = transform_points(center_coordinate.reshape(1, 3), np.linalg.inv(H0_wc))

        result = result.flatten()
        centers.append(result)

    # 打印或处理重建的中心点
    print("Reconstructed 3D centers:", centers)
    '''
    Task 7: Evaluate and Display the centres

    Write your code here
    '''
    # 以下内容全部是画ground truth！！！

    # 新的渲染函数，仅渲染平面和圆心,这里是创建一个只有平面和圆心的场景，为了我们后面重建圆心！
    def render_plane_and_centers(meshes, centers_pcd, camera_poses, img_width, img_height, K):
        vis = o3d.visualization.Visualizer()
        vis.create_window(width=img_width, height=img_height, left=0, top=0)
        vis.add_geometry(meshes[0])  # 添加平面
        vis.add_geometry(centers_pcd)  # 添加圆心点云
        cam = o3d.camera.PinholeCameraParameters()
        cam.intrinsic = K
        ctr = vis.get_view_control()
        for (H_wc, name, _) in camera_poses:
            cam.extrinsic = H_wc
            ctr.convert_from_pinhole_camera_parameters(cam)
            vis.poll_events()
            vis.update_renderer()
            vis.capture_screen_image(name, True)  # 只保存RGB图像
        vis.destroy_window()


    # 创建表示球体圆心的点云
    def create_sphere_centers_pointcloud(centers):
        pcd_centers = o3d.geometry.PointCloud()
        pcd_centers.points = o3d.utility.Vector3dVector(centers)
        pcd_centers.paint_uniform_color([0, 1, 0])  # 绿色
        return pcd_centers


    # 在主函数中计算所有球体的圆心
    sphere_centers = [center[:3] for center in GT_cents]  # 只取每个中心的前三个坐标

    # 创建表示球体圆心的点云
    pcd_centers = create_sphere_centers_pointcloud(sphere_centers)

    # 渲染并保存包含平面和圆心的图片
    plane_and_centers_poses = [(H0_wc, 'reconstructCenter/plane_centers_view0.png', None),
                               (H1_wc, 'reconstructCenter/plane_centers_view1.png', None)]
    render_plane_and_centers(obj_meshes, pcd_centers, plane_and_centers_poses, img_width, img_height, K)

    # 加载两个相机捕捉的图像
    img_cam0 = cv2.imread('reconstructCenter/plane_centers_view0.png', -1)
    img_cam1 = cv2.imread('reconstructCenter/plane_centers_view1.png', -1)

    #以上内容全部是画ground truth！！！

    #以下内容是把重建出的3D圆心分别投影到两个相机上，然后观察效果
    for P in centers:
        # 投影到相机0的图像平面
        P_cam0_2d = transform_points(P[np.newaxis, :], H0_wc)
        P_cam0_2d = np.dot(K.intrinsic_matrix, P_cam0_2d.T).T
        P_cam0_2d = P_cam0_2d[:, :2] / P_cam0_2d[:, 2][:, np.newaxis]

        # 投影到相机1的图像平面
        P_cam1_2d = transform_points(P[np.newaxis, :], H1_wc)
        P_cam1_2d = np.dot(K.intrinsic_matrix, P_cam1_2d.T).T
        P_cam1_2d = P_cam1_2d[:, :2] / P_cam1_2d[:, 2][:, np.newaxis]

        # 在两个图像上标记投影后的圆心
        cv2.circle(img_cam0, (int(P_cam0_2d[0][0]), int(P_cam0_2d[0][1])), 5, (0, 0, 255), -1)
        cv2.circle(img_cam1, (int(P_cam1_2d[0][0]), int(P_cam1_2d[0][1])), 5, (0, 0, 255), -1)

    # 保存或显示结果图像
    cv2.imwrite('reconstructCenter/view0_with_reconstructed_centers.png', img_cam0)
    cv2.imwrite('reconstructCenter/view1_with_reconstructed_centers.png', img_cam1)

    ###################################
    '''
    Task 8: 3-D radius of spheres

    Write your code here
    '''
    ###################################
    def find_circle_line_intersections(xc, yc, r, line):
        # 计算圆和直线的交点
        a, b, c = line
        c = c + a * xc + b * yc  # 转换到以圆心为原点的坐标系
        x0, y0 = -a * c / (a ** 2 + b ** 2), -b * c / (a ** 2 + b ** 2)
        d = r ** 2 - (x0 ** 2 + y0 ** 2)  # 判别式

        if d < 0:
            return []  # 无交点，理论上不应该发生，如果所有直线都与圆相交

        d_sqrt = np.sqrt(d)
        mult = d_sqrt / np.sqrt(a ** 2 + b ** 2)
        ax, ay = x0 + b * mult, y0 - a * mult
        bx, by = x0 - b * mult, y0 + a * mult

        # 根据 d 的值确定返回一个还是两个交点
        if d == 0:
            return [(ax + xc, ay + yc)]  # 一个交点
        else:
            return [(ax + xc, ay + yc), (bx + xc, by + yc)]  # 两个交点


    def draw_circle_edge_matches(img0new, img1new, circles0):
        img0_with_matches = img0new.copy()
        img1_with_matches = img1new.copy()
        matched_circle_edges = []  # 用于保存匹配的圆边缘点对

        # 随机选择圆边缘上的点进行匹配
        for i0, matched_circle in enumerate(matched_circles):
            x0, y0, r0 = matched_circle[1][:3]  # 假设matched_circle的结构是[[x1_match, y1_match, r1_match], [x0, y0, r0]]
            # 随机角度以选择圆上的一个点
            # theta = random.uniform(0, 2 * np.pi)
            # edge_x0 = int(x0 + r0 * np.cos(theta))
            # edge_y0 = int(y0 + r0 * np.sin(theta))

            x0, y0, r0 = matched_circle[1][:3]  # 圆心和半径
            edge_x0 = int(x0 + r0)  # 圆右边与x轴平行的点的x坐标
            edge_y0 = y0  # 圆右边与x轴平行的点的y坐标与圆心的y坐标相同

            point0 = np.array([edge_x0, edge_y0, 1])  # 圆边缘点的齐次坐标
            line1 = F @ point0  # 圆边缘点在图像1上对应的极线

            pt1 = (0, int(-line1[2] / line1[1]))
            pt2 = (img_width, int(-(line1[2] + line1[0] * img_width) / line1[1]))
            # 在相机1的图像上绘制极线
            cv2.line(img1_with_matches, pt1, pt2, (0, 255, 0), 2)

            # 确定与圆心i0匹配的圆i1
            matched_circle_tmp = matched_circles[i0]
            # matched_circle 的结构是 [[closest_x1, closest_y1, r1], [x0, y0, r0]]
            x1_match, y1_match, r1_match = matched_circle_tmp[0][:3]
            x1_match = int(x1_match)
            y1_match = int(y1_match)
            r1_match = int(r1_match)


            # 计算圆和极线是否有交点！
            intersections = find_circle_line_intersections(x1_match, y1_match, r1_match, line1)
            if intersections:
                # 选择x坐标最大的交点
                ix, iy = max(intersections, key=lambda point: point[0])
                ix = int(ix)
                iy = int(iy)
                color = (np.random.randint(0, 255), np.random.randint(0, 255), np.random.randint(0, 255))
                cv2.circle(img1_with_matches, (ix, iy), 5, color, -1)
                matched_circle_edges.append([[ix, iy, r1_match], [edge_x0, edge_y0, r0]])
                # for ix, iy in intersections:
                #     ix = int(ix)
                #     iy = int(iy)
                #     color = (np.random.randint(0, 255), np.random.randint(0, 255), np.random.randint(0, 255))
                #     # cv2.circle(img0_with_matches, (edge_x0, edge_y0), 5, color, -1)
                #     # cv2.circle(img1_with_matches, (ix, iy), 5, color, -1)
                #     matched_circle_edges.append([[ix, iy, r1_match], [edge_x0, edge_y0, r0]])
            else:
                # 如果没有交点，在圆i1的边缘上找到最接近极线的点，就在圆上均匀取点，找到最接近极线的点
                min_distance = float('inf')
                closest_edge_point = None
                for theta1 in np.linspace(0, 2 * np.pi, 100):  # 在圆上均匀取点
                    edge_x1 = int(x1_match + r1_match * np.cos(theta1))
                    edge_y1 = int(y1_match + r1_match * np.sin(theta1))
                    point1 = np.array([edge_x1, edge_y1, 1])
                    distance = abs(np.dot(line1, point1)) / np.linalg.norm(line1[:2])
                    if distance < min_distance:
                        min_distance = distance
                        closest_edge_point = (edge_x1, edge_y1)

                if closest_edge_point is not None:
                    edge_x1_closest, edge_y1_closest = closest_edge_point
                    color = (np.random.randint(0, 255), np.random.randint(0, 255), np.random.randint(0, 255))
                    # cv2.circle(img0_with_matches, (edge_x0, edge_y0), 5, color, -1)
                    # cv2.circle(img1_with_matches, (edge_x1_closest, edge_y1_closest), 5, color, -1)
                    matched_circle_edges.append([[edge_x1_closest, edge_y1_closest, r1_match], [edge_x0, edge_y0, r0]])

        return img0_with_matches, img1_with_matches, matched_circle_edges

    # 绘制检测到的圆
    if circles0 is not None:
        circles = np.uint16(np.around(circles0))
        for i in circles[0, :]:
            center = (i[0], i[1])  # 圆心坐标
            radius = i[2]  # 半径
            cv2.circle(img_cam0, center, radius, (0, 0, 255), 2)

    if circles1 is not None:
        circles = np.uint16(np.around(circles1))
        for i in circles[0, :]:
            center = (i[0], i[1])
            radius = i[2]
            cv2.circle(img_cam1, center, radius, (0, 0, 255), 2)

    matched_img0c, matched_img1c, matched_circle_edges = draw_circle_edge_matches(img_cam0, img_cam1, circles0)

    '''
    Task 9: Display the spheres

    Write your code here:
    '''
    #我现在把过滤过后的边重建到3D空间中，然后计算半径
    edge = []
    K_inverse = np.linalg.inv(K.intrinsic_matrix)
    H_10 = np.matmul(H0_wc, np.linalg.inv(H1_wc))
    rotation_matrix = H_10[:3, :3].T
    T = H_10[:3, 3]
    for correspondance in matched_circle_edges:
        l = correspondance[1][:2]
        l.append(1)
        l = np.array(l)
        r = correspondance[0][:2]
        r.append(1)
        r = np.array(r)
        l = np.matmul(K_inverse, l)
        r = np.matmul(K_inverse, r)
        j = -np.matmul(rotation_matrix.T, r)
        k = -np.cross(l, np.matmul(rotation_matrix.T, r))
        H = np.concatenate((l.reshape(3, 1), j.reshape(3, 1), k.reshape(3, 1)), axis=1)
        reconstruct_array = np.matmul(np.linalg.inv(H), T)
        center_coordinate = (reconstruct_array[0] * l + reconstruct_array[1] * np.matmul(rotation_matrix.T, r) + T) / 2
        result = transform_points(center_coordinate.reshape(1, 3), np.linalg.inv(H0_wc))

        result = result.flatten()
        edge.append(result)

    # 这个edge是每个球的半径，centers中含有的是每个球的中心点
    # 然后我现在要计算每个三维球体的半径

    img_cameranew0 = cv2.imread('reconstructCenter/plane_centers_view0.png', -1)
    img_cameranew1 = cv2.imread('reconstructCenter/plane_centers_view1.png', -1)

    # sphere display :
    for sphere_centre, edge in zip(centers, edge):
        radius = np.linalg.norm(edge - sphere_centre)
        c_x, c_y, c_z = sphere_centre
        N = 100  # 取样点数量

        # 生成球体的表面点
        sample_list = []
        sample_x = np.random.uniform(low=min(c_x - radius, c_x + radius), high=max(c_x - radius, c_x + radius), size=N)
        for x in sample_x:
            length_x = abs(x - c_x)
            r_circle = np.sqrt(radius ** 2 - length_x ** 2)
            sample_y = np.random.uniform(low=c_y - r_circle, high=c_y + r_circle, size=N)
            for y in sample_y:
                theta = np.arccos((y - c_y) / r_circle)
                z1 = c_z + r_circle * np.sin(theta)
                z2 = c_z - r_circle * np.sin(theta)
                sample_list.extend([[x, y, z1], [x, y, z2]])

        # 对每个点进行投影
        for point in sample_list:
            point_3d = np.array([point])

            # 投影到相机0的图像平面
            P_cam0_2d = transform_points(point_3d, H0_wc)
            P_cam0_2d = np.dot(K.intrinsic_matrix, P_cam0_2d.T).T
            P_cam0_2d = P_cam0_2d[:, :2] / P_cam0_2d[:, 2][:, np.newaxis]

            # 投影到相机1的图像平面
            P_cam1_2d = transform_points(point_3d, H1_wc)
            P_cam1_2d = np.dot(K.intrinsic_matrix, P_cam1_2d.T).T
            P_cam1_2d = P_cam1_2d[:, :2] / P_cam1_2d[:, 2][:, np.newaxis]

            # 在两个图像上标记投影后的点
            cv2.circle(img_cameranew0, (int(P_cam0_2d[0][0]), int(P_cam0_2d[0][1])), 2, (0, 255, 0), -1)
            cv2.circle(img_cameranew1, (int(P_cam1_2d[0][0]), int(P_cam1_2d[0][1])), 2, (0, 255, 0), -1)

    # 保存投影结果
    cv2.imwrite('projected_view0.png', img_cameranew0)
    cv2.imwrite('projected_view1.png', img_cameranew1)

    ###################################
    '''
    Task 10: Investigate impact of noise added to relative pose

    Write your code here:
    '''
    ###################################
