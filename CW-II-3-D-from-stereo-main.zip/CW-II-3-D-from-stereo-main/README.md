# Coursework-Part2-3D-from-stereo

Python code for Part 2 of the coursework assignment on 3D from stereo. 

This part of the assignment assumes that you have completed the Stereo Lab Sheets. The assignment involves determining corresponding spheres in two views of a scene consisting of spheres on a plane and using the correspondences to reconstruct the spheres and their centre points. You are required to submit your code and a report that describes and explains the tasks completed, your experiments and the results obtained. Both the code and the report are required to obtain marks.
